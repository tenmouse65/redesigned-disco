Remove Potion Particles resource pack for Minecraft 1.18.

Get the latest version at: https://www.curseforge.com/minecraft/texture-packs/remove-potion-particles

Version: Minecraft 1.18, Release 1.2
Made On: 2021.07.12
Made By: Brandonmccoub2 on CurseForge (98SE on Minecraft Java)
Updated: 2021.12.01

--------------------------------------------------------------------------------------------------------------

Changelog: 

	v1.2:
	2021.12.01: -Added support for Minecraft 1.18 (which was released yesterday) 
	
	v1.1:
	2021.07.16: -Fixed an issue with blue particle flickering around the player in versions 1.6.1 to 1.12.2.
				-Fixed an issue where I used 8-bit colour depth instead of 32-bit causing the edge of semi 
				 transparent particles to be chopped off in versions 1.9 to 1.12.2.

--------------------------------------------------------------------------------------------------------------

Extra Info:

	-I have to update every version even if the patch only effects 1 version or it'll show up on CurseForge as 
	an old version, for example if I just update the 1.8.9 pack CurseForge will show the mod in the Game 
	Version section as 1.8.9.

--------------------------------------------------------------------------------------------------------------